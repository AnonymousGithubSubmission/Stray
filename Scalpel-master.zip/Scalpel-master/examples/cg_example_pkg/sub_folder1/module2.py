class Module2(object):
    def minus(self,a,b):
        b=b-1
        return a-b