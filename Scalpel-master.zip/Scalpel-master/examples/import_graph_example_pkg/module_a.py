from .module_b import B
from .module_c import C

class A:
    def foo(self):
        return