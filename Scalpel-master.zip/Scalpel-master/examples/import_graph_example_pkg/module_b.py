from .module_c import C

class B:
    def foo(self):
        return