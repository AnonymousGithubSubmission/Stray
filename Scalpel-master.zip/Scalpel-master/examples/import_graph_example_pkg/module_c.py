import os

class C:
    def foo(self):
        return