from os import getcwd


def my_function():
    x = "Current working directory: "
    return x + getcwd()
