def func(a:int, b:int)->str:
    if True:
        a = str(a)
    else:
        a = 10
    return a

res = func(10,20)
