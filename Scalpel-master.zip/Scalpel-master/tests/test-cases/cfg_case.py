def random_date(start,l):
    pass
   #current = start
   #while l >= 0:
   #   curr = current + datetime.timedelta(minutes=randrange(120))
   #   yield curr
   #   l-=1
random_date = []
startDate = datetime.datetime(2016,5,5,7,00)
wakeup_time = []
for x in random_date(startDate,n):
    print('hi')
    pass
