#No phi nodes are placed

# we need a case when no phi function placed for different blocks
c = 10
if c:
    print(c)
else:
    t = 0
print(t)
