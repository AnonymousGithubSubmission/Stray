a = 10
if isinstance(a, int):
    b = "abc"
else:
    b = 10.0

b = "abc"
c = a*b


