a = b = 10
print(a)
print(b)
